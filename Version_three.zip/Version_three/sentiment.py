from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

analyzer = SentimentIntensityAnalyzer()

def get_sentiment(text):
    scores = analyzer.polarity_scores(text)

    compound = scores['compound']

    if compound >= 0.05:
        sentiment = "Positive"
        intensity = scores['pos']
    elif compound <= -0.05:
        sentiment = "Negative"
        intensity = scores['neg']
    else:
        sentiment = "Neutral"
        intensity = scores['neu']

    return sentiment, round(intensity, 2)


# Optional standalone test
if __name__ == "__main__":
    print("Sentiment Analyzer (type 'exit' to quit)\n")

    while True:
        msg = input("Message: ")

        if msg.lower() == "exit":
            break

        sentiment, intensity = get_sentiment(msg)

        print("\nInput:", msg)
        print("Final sentiment:", sentiment)
        print("Intensity:", intensity)
